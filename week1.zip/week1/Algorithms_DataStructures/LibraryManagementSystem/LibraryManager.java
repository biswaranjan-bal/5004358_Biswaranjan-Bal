package week1.Algorithms_DataStructures.LibraryManagementSystem;

class Book {
    int bookId;
    String title;
    String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }
}

public class LibraryManager {
    private Book[] books;

    public LibraryManager(Book[] books) {
        this.books = books;
    }

    // Linear search by title
    public Book linearSearchByTitle(String targetTitle) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(targetTitle)) {
                return book;
            }
        }
        return null; // Not found
    }

    // Binary search by title (assuming the list is sorted)
    public Book binarySearchByTitle(String targetTitle) {
        int low = 0;
        int high = books.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            int comparison = books[mid].title.compareToIgnoreCase(targetTitle);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null; // Not found
    }

    public static void main(String[] args) {
        Book[] bookList = {
            new Book(101, "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book(102, "To Kill a Mockingbird", "Harper Lee"),
            // Add more books as needed
        };

        LibraryManager library = new LibraryManager(bookList);

        // Example usage
        Book foundBook = library.linearSearchByTitle("To Kill a Mockingbird");
        if (foundBook != null) {
            System.out.println("Found book: " + foundBook.title + " by " + foundBook.author);
        } else {
            System.out.println("Book not found.");
        }

        // Assuming the list is sorted by title
        Book binaryFoundBook = library.binarySearchByTitle("The Great Gatsby");
        if (binaryFoundBook != null) {
            System.out.println("Found book (binary search): " + binaryFoundBook.title);
        } else {
            System.out.println("Book not found (binary search).");
        }
    }
}

