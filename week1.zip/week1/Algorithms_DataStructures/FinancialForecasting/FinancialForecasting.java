package week1.Algorithms_DataStructures.FinancialForecasting;

public class FinancialForecasting {

    // Recursive function to calculate future value
    public static double predictFutureValue(double presentValue, double growthRate, int years) {
        if (years == 0) {
            return presentValue; // Base case: no more years left
        }
        // Calculate the value after one year
        double futureValue = presentValue * (1 + growthRate);
        // Recursively predict the value for the remaining years
        return predictFutureValue(futureValue, growthRate, years - 1);
    }

    public static void main(String[] args) {
        double initialInvestment = 1000.0; // Present value
        double annualGrowthRate = 0.05; // 5% growth rate per year
        int forecastYears = 10;

        double futureValue = predictFutureValue(initialInvestment, annualGrowthRate, forecastYears);
        System.out.println("Predicted future value after " + forecastYears + " years: $" + futureValue);
    }
}

