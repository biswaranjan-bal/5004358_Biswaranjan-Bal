package week1.Algorithms_DataStructures.TaskManagementSystem;

class Task {
    int taskId;
    String taskName;
    boolean status; // true for completed, false for pending

    public Task(int taskId, String taskName) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = false; // Initialize as pending
    }
}
class TaskNode {
    Task task;
    TaskNode next;

    public TaskNode(Task task) {
        this.task = task;
        this.next = null;
    }
}

public class TaskManager {
    private TaskNode head;

    // Add a task to the end of the list
    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (head == null) {
            head = newNode;
        } else {
            TaskNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by ID
    public Task findTaskById(int taskId) {
        TaskNode current = head;
        while (current != null) {
            if (current.task.taskId == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null; // Not found
    }

    // Traverse and display all tasks
    public void displayAllTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println(current.task.taskName + " (" + (current.task.status ? "Completed" : "Pending") + ")");
            current = current.next;
        }
    }

    // Delete a task by ID
    public void deleteTask(int taskId) {
        if (head == null) {
            System.out.println("No tasks to delete.");
            return;
        }
        if (head.task.taskId == taskId) {
            head = head.next;
            System.out.println("Task with ID " + taskId + " deleted.");
            return;
        }
        TaskNode prev = head;
        TaskNode current = head.next;
        while (current != null) {
            if (current.task.taskId == taskId) {
                prev.next = current.next;
                System.out.println("Task with ID " + taskId + " deleted.");
                return;
            }
            prev = current;
            current = current.next;
        }
        System.out.println("Task with ID " + taskId + " not found.");
    }

    public static void main(String[] args) {
        // Example usage
        TaskManager manager = new TaskManager();
        manager.addTask(new Task(101, "Write report"));
        manager.addTask(new Task(102, "Prepare presentation"));

        Task foundTask = manager.findTaskById(101);
        if (foundTask != null) {
            System.out.println("Found task: " + foundTask.taskName);
        } else {
            System.out.println("Task not found.");
        }

        manager.displayAllTasks();

        manager.deleteTask(102);
        manager.displayAllTasks();
    }
}
