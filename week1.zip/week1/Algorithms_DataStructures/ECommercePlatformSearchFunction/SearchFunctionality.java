class Product {
    int productId;
    String productName;
    String category;

    public Product(int productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }
}

public class SearchFunctionality {
    // Linear search
    public static int linearSearch(Product[] products, int targetId) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].productId == targetId) {
                return i;
            }
        }
        return -1;
    }

    // Binary search (assuming products are sorted by productId)
    public static int binarySearch(Product[] products, int targetId) {
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].productId == targetId) {
                return mid;
            } else if (products[mid].productId < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        // Example usage
        Product[] productList = {
            new Product(101, "Laptop", "Electronics"),
            new Product(202, "Shoes", "Fashion"),
            new Product(303, "Book", "Books"),
            // Add more products as needed
        };

        int targetProductId = 202;
        int linearResult = linearSearch(productList, targetProductId);
        int binaryResult = binarySearch(productList, targetProductId);

        System.out.println("Linear search result: " + linearResult); // Output: 1
        System.out.println("Binary search result: " + binaryResult); // Output: 1
    }
}
