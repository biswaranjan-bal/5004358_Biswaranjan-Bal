class Employee {
    int employeeId;
    String name;
    String position;
    double salary;

    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }
}
public class EmployeeManagementSystem {
    private static final int MAX_EMPLOYEES = 100; // Set an appropriate limit

    private Employee[] employees;
    private int numEmployees;

    public EmployeeManagementSystem() {
        employees = new Employee[MAX_EMPLOYEES];
        numEmployees = 0;
    }

    // Add an employee
    public void addEmployee(Employee emp) {
        if (numEmployees < MAX_EMPLOYEES) {
            employees[numEmployees] = emp;
            numEmployees++;
        } else {
            System.out.println("Employee database is full.");
        }
    }

    // Search for an employee by ID
    public Employee findEmployeeById(int empId) {
        for (int i = 0; i < numEmployees; i++) {
            if (employees[i].employeeId == empId) {
                return employees[i];
            }
        }
        return null; // Not found
    }

    // Traverse and display all employees
    public void displayAllEmployees() {
        for (int i = 0; i < numEmployees; i++) {
            System.out.println(employees[i].name + " (" + employees[i].position + ")");
        }
    }

    // Delete an employee by ID
    public void deleteEmployee(int empId) {
        for (int i = 0; i < numEmployees; i++) {
            if (employees[i].employeeId == empId) {
                // Shift remaining elements to fill the gap
                for (int j = i; j < numEmployees - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                numEmployees--;
                System.out.println("Employee with ID " + empId + " deleted.");
                return;
            }
        }
        System.out.println("Employee with ID " + empId + " not found.");
    }

    public static void main(String[] args) {
        // Example usage
        EmployeeManagementSystem system = new EmployeeManagementSystem();
        system.addEmployee(new Employee(101, "John Doe", "Manager", 75000.0));
        system.addEmployee(new Employee(102, "Jane Smith", "Developer", 60000.0));

        Employee foundEmployee = system.findEmployeeById(101);
        if (foundEmployee != null) {
            System.out.println("Found employee: " + foundEmployee.name);
        } else {
            System.out.println("Employee not found.");
        }

        system.displayAllEmployees();

        system.deleteEmployee(102);
        system.displayAllEmployees();
    }
}
